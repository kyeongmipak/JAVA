package com.javalec.function;

public class Car {
	// field
	public String company ="현대자동차"; // 다른 클래스에서는 private이므로 public을 붙여준다.
	public String model = "그랜져";
	public String color = "검정";
	public int maxSpeed = 350;
	public int speed;
	
	// constructor
	public Car() {
		// TODO Auto-generated constructor stub
	}
	
	// method
	// 메소드 입력 안해도 된다.
	
	
}
